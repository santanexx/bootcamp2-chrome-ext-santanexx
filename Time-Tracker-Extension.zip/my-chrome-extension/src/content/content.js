// Destaca todos os links da página
for (const a of document.querySelectorAll("a")) {
  a.style.outline = "2px solid #ec0089";
}
